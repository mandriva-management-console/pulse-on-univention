#!/usr/bin/python
# -*- coding: utf-8 -*-

from ConfigParser import ConfigParser
import urllib2
import os
import HTMLParser
import pprint
from lxml import etree
import uuid
import sys
import shutil
import re

pathname = os.path.dirname(sys.argv[0])        
SCRIPT_PATH = os.path.abspath(pathname)

PACKAGES_DIR = "/var/lib/pulse2/packages/"
INI_FILES_DIR = SCRIPT_PATH + "/ini_files/"

def chunk_report(bytes_so_far, chunk_size, total_size):
    percent = float(bytes_so_far) / total_size
    percent = round(percent*100, 2)
    sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % 
                     (bytes_so_far, total_size, percent))

    if bytes_so_far >= total_size:
        sys.stdout.write('\n')

def chunk_read(response, f, chunk_size=8192, report_hook=None):
    total_size = response.info().getheader('Content-Length').strip()
    total_size = int(total_size)
    bytes_so_far = 0

    while 1:
        chunk = response.read(chunk_size)
        bytes_so_far += len(chunk)

        if chunk:
            f.write(chunk)
        else:
            break

        if report_hook:
            report_hook(bytes_so_far, chunk_size, total_size)

    f.close()
    return bytes_so_far


def download_package(config, uuid_name):
    """ Download package set in config variable """
    print ("Downloading %s") % config['filename']
    dirname = PACKAGES_DIR + uuid_name
    if not os.access(dirname, os.F_OK): os.mkdir(dirname)
    try:
        url = urllib2.Request("http://" + urllib2.quote(config['url'])) 
        # Additionnal headers (cookies...) may be required
        if config.has_key('additionnalheader'):
            # Must be like header1 || value1 @@ header2 || value2
            for header in config['additionnalheader'].split('@@'):
                additionnalheader_type = header.split('||')[0].strip()
                additionnalheader_value = header.split('||')[1].strip()
                url.add_header(additionnalheader_type, additionnalheader_value)
        package = urllib2.urlopen(url)
        # urllib2.quote() is for replacing spaces by "%20"
        f = open(os.path.join(dirname,config['filename']), 'w')
        chunk_read(package, f, report_hook=chunk_report)
    except Exception, e:
        raise Exception("%s : %s" % (config['url'], e))
    return False

def create_node(section, config, uuid_name):
    """ Create XML Node """
    if section == 'downloadurl':
        download_package(config, uuid_name)
        return None
    else:
        node = etree.Element(section)
        for option in sorted(config.keys()):
            if option.endswith('_class'):
                class_parent = option[:-6]
                tmp = config[option].split(' ')
                if class_parent == node.tag:
                    node.set(tmp[0], tmp[1])
                else:
                    elem = node.find(class_parent)
                    try:
                        elem.set(tmp[0], tmp[1])
                    except:
                        elem.set(tmp[0], "")
            else:
                if section == option:
                    node.text = config[option]
                else:
                    children = node.makeelement(option)
                    children.text = config[option]
                    node.append(children)
        
        return node

def get_package(ini_file):
    """ Create XML File and download package from ini_file"""

    configparser = ConfigParser()
    configparser.read(INI_FILES_DIR + ini_file)
    sections = configparser.sections()
    
    package = etree.Element('package')
    uuid_name = str(uuid.uuid1())
    package.set('id', uuid_name)

    for section in sections:
        options = configparser.options(section)

        config = dict()
        for option in options:
            config[option] = configparser.get(section, option)

        node = create_node(section, config, uuid_name)
        if node is not None: package.append(create_node(section, config, uuid_name))
    
    f = open(PACKAGES_DIR + uuid_name + '/conf.xml', 'w')
    #print(etree.tostring(package, pretty_print=True))
    f.write("""<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE package [
    <!ELEMENT package (name,version,description?,commands,files?)>
    <!ATTLIST package id ID #REQUIRED>

    <!ELEMENT name (#PCDATA)>
    <!ELEMENT version (numeric,label)>
    <!ELEMENT numeric (#PCDATA)>
    <!ELEMENT label (#PCDATA)>
    <!ELEMENT description (#PCDATA)>

    <!ELEMENT commands (preCommand?,installInit?,command,postCommandSuccess?,postCommandFailure?)>
    <!ATTLIST commands reboot (0|1) "0">
    <!ELEMENT preCommand (#PCDATA)>
    <!ATTLIST preCommand name CDATA "">
    <!ELEMENT installInit (#PCDATA)>
    <!ATTLIST installInit name CDATA "">
    <!ELEMENT command (#PCDATA)>
    <!ATTLIST command name CDATA "">
    <!ELEMENT postCommandSuccess (#PCDATA)>
    <!ATTLIST postCommandSuccess name CDATA "">
    <!ELEMENT postCommandFailure (#PCDATA)>
    <!ATTLIST postCommandFailure name CDATA "">

    <!ELEMENT files (file*)>
    <!ELEMENT file (#PCDATA)>
    <!ATTLIST file fid ID #IMPLIED>
    <!ATTLIST file md5sum CDATA "">
    <!ATTLIST file size CDATA "">
]>
""")
    f.write(etree.tostring(package, pretty_print=True))
    f.close()
        
if os.access(PACKAGES_DIR, os.F_OK): shutil.rmtree(PACKAGES_DIR)
os.mkdir(PACKAGES_DIR)

for ini_file in os.listdir(INI_FILES_DIR):
    if ini_file.endswith(".ini"):
        get_package(ini_file)
