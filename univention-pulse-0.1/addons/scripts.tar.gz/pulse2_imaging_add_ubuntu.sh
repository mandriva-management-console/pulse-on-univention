#!/bin/bash

PULSE2_IP=`grep public_ip /etc/mmc/pulse2/package-server/package-server.ini |cut -d= -f2 | sed 's/ //g'`
MYSQL_INSERT="INSERT INTO BootService (default_name, default_desc, fk_name, fk_desc, value) VALUES ('Ubuntu Live 64bits', 'Run Ubuntu Live 64bits', 1, 1, 'kernel (nd)/tools/ubuntu/livecd64/casper/vmlinuz.efi boot=casper netboot=nfs nfsroot=${PULSE2_IP}:/var/lib/pulse2/imaging/tools/ubuntu/livecd64/ initrd=casper/initrd.gz locale=fr_FR bootkbd=fr console-setup/layoutcode=fr
initrd (nd)/tools/ubuntu/livecd64/casper/initrd.lz');
INSERT INTO BootService (default_name, default_desc, fk_name, fk_desc, value) VALUES ('Ubuntu Live 32bits', 'Run Ubuntu Live 32bits', 1, 1, 'kernel (nd)/tools/ubuntu/livecd32/casper/vmlinuz boot=casper netboot=nfs nfsroot=${PULSE2_IP}:/var/lib/pulse2/imaging/tools/ubuntu/livecd32/ initrd=casper/initrd.gz locale=fr_FR bootkbd=fr console-setup/layoutcode=fr
initrd (nd)/tools/ubuntu/livecd32/casper/initrd.lz');"

UBUNTU_VERSION="13.04"
UBUNTU_HTTP="http://releases.ubuntu.mirrors.uk2.net/raring/"
UBUNTU_ISO64="ubuntu-$UBUNTU_VERSION-desktop-amd64.iso"
UBUNTU_ISO32="ubuntu-$UBUNTU_VERSION-desktop-i386.iso"

UBUNTU_PULSE_DIR="/var/lib/pulse2/imaging/tools/ubuntu"
UBUNTU_32_DIR="livecd32"
UBUNTU_64_DIR="livecd64"

## Let's go

if [ ! -e ${UBUNTU_PULSE_DIR} ]; then
	mkdir -p ${UBUNTU_PULSE_DIR}
fi

cd ${UBUNTU_PULSE_DIR}

# Get Ubuntu 32bit/64bit LiveCD

wget $UBUNTU_HTTP/$UBUNTU_ISO64
wget $UBUNTU_HTTP/$UBUNTU_ISO32

mv ${UBUNTU_ISO64} ubuntu64.iso
mv ${UBUNTU_ISO32} ubuntu32.iso

# Create mount points if don't exist

if [ ! -e ${UBUNTU_32_DIR} ]; then
	mkdir -p ${UBUNTU_32_DIR}
fi

if [ ! -e ${UBUNTU_64_DIR} ]; then
	mkdir -p ${UBUNTU_64_DIR}
fi

# Add mount points to /etc/fstab if don't exist

FSTAB_MODIFIED=0

if ! `grep -q ${UBUNTU_PULSE_DIR}/${UBUNTU_64_DIR} /etc/fstab`; then
	echo "${UBUNTU_PULSE_DIR}/ubuntu64.iso ${UBUNTU_PULSE_DIR}/${UBUNTU_64_DIR} iso9660 loop,ro,auto 0 0" >> /etc/fstab
	FSTAB_MODIFIED=1
fi

if ! `grep -q ${UBUNTU_PULSE_DIR}/${UBUNTU_32_DIR} /etc/fstab`; then
	echo "${UBUNTU_PULSE_DIR}/ubuntu32.iso ${UBUNTU_PULSE_DIR}/${UBUNTU_32_DIR} iso9660 loop,ro,auto 0 0" >> /etc/fstab
	FSTAB_MODIFIED=1
fi

if [ ${FSTAB_MODIFIED} == 1 ]; then
	mount -a
fi

# Create NFS Shares if they don't exist

EXPORTS_MODIFIED=0

if ! `grep -q ${UBUNTU_PULSE_DIR}/${UBUNTU_32_DIR} /etc/exports`; then
	echo "${UBUNTU_PULSE_DIR}/${UBUNTU_32_DIR} *(async,ro,no_subtree_check,no_root_squash)" >> /etc/exports
	EXPORTS_MODIFIED=1
fi

if ! `grep -q ${UBUNTU_PULSE_DIR}/${UBUNTU_64_DIR} /etc/exports`; then
	echo "${UBUNTU_PULSE_DIR}/${UBUNTU_64_DIR} *(async,ro,no_subtree_check,no_root_squash)" >> /etc/exports
	EXPORTS_MODIFIED=1
fi

if [ ${EXPORTS_MODIFIED} == 1 ]; then
	/etc/init.d/nfs-kernel-server restart
fi

echo -e "${MYSQL_INSERT}" | mysql imaging
