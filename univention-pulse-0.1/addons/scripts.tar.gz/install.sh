#!/bin/bash
create_boot_service() {
    PULSE2_DIR="/var/lib/pulse2/imaging/tools/debian"
    if [ $1 ]; then
        DEBIAN_VERSION=$1;
    fi
    if [ $2 ]; then
        ARCH=$2
    fi

    PULSE2_DIR=${PULSE2_DIR}/${DEBIAN_VERSION}/${ARCH}
    if [ ! -e ${PULSE2_DIR} ]; then
        mkdir -p ${PULSE2_DIR}
    fi

    cd ${PULSE2_DIR}
    wget http://ftp.fr.debian.org/debian/dists/$DEBIAN_VERSION/main/installer-$ARCH/current/images/netboot/netboot.tar.gz
    tar xzf netboot.tar.gz
    rm netboot.tar.gz
    mysql imaging -e "INSERT INTO BootService (default_name, default_desc, fk_name, fk_desc, value) VALUES (\"Debian ${DEBIAN_VERSION} ${ARCH} Netboot\", \"Debian ${DEBIAN_VERSION} ${ARCH} Netboot\", 1, 1, \"kernel (nd)/tools/debian/${DEBIAN_VERSION}/${ARCH}/debian-installer/${ARCH}/linux
initrd=(nd)/tools/debian/${DEBIAN_VERSION}/${ARCH}/debian-installer/${ARCH}/initrd.gz --quiet\")"
}

add_firmwares() {
    FWTMP=/tmp/d-i_firmware
    rm -rf $FWTMP
    mkdir  -p $FWTMP/firmware
    cd $FWTMP
    
    wget http://cdimage.debian.org/cdimage/unofficial/non-free/firmware/wheezy/current/firmware.tar.gz
    
    cd firmware
    tar -zxf ../firmware.tar.gz
    cd ../
    
    pax -x sv4cpio -s'%firmware%/firmware%' -w firmware | gzip -c >firmware.cpio.gz
    
    # cd to the directory where you have your initrd
    for DIR in /var/lib/pulse2/imaging/tools/debian/wheezy/amd64/debian-installer/amd64 /var/lib/pulse2/imaging/tools/debian/wheezy/i386/debian-installer/i386; do
      cd $DIR
      [ -f initrd.gz.orig ] || cp -p initrd.gz initrd.gz.orig
      cat initrd.gz.orig $FWTMP/firmware.cpio.gz > initrd.gz
    done
}

# Test if pax is present on the system
command -v pax >/dev/null 2>&1 || { echo >&2 "pax is not installed. Please apt-get install pax"; exit 1;}

# Add boot services
create_boot_service wheezy amd64
create_boot_service wheezy i386

# Add firmwares
add_firmwares
