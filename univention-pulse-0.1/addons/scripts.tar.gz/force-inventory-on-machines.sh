#!/bin/sh

for machine in hostname1 hostname2 hostname3; do
  echo "Processing $machine..."
  echo "######################"
  ssh $machine "test -e /cygdrive/c/Program\ Files/FusionInventory-Agent && cd /cygdrive/c/Program\ Files/FusionInventory-Agent && ./fusioninventory-agent.bat"
  ssh $machine "test -e /cygdrive/c/Program\ Files\ \(x86\)/FusionInventory-Agent && cd /cygdrive/c/Program\ Files\ \(x86\)/FusionInventory-Agent && ./fusioninventory-agent.bat"
  ssh $machine "test -e /etc/cron.daily/fusioninventory-agent && /etc/cron.daily/fusioninventory-agent"
  echo
  echo
done
