#!/bin/sh

export DEBIAN_FRONTEND=noninteractive
sudo apt-get update
sudo apt-get -y -o APT::Get::AllowUnauthenticated=yes install fusioninventory-agent rsync

sudo sed -i '0,/^#*server[[:space:]]*=.*$/s//server = http:\/\/@@@PULSE_SRV_FQDN@@@:9999/' /etc/fusioninventory/agent.cfg 

sudo /etc/cron.daily/fusioninventory-agent

sudo mkdir -p /root/.ssh/
sudo sh -c "echo '@@@PULSE_SRV_ID_RSA_PUB_CONTENT@@@' >> /root/.ssh/authorized_keys"
